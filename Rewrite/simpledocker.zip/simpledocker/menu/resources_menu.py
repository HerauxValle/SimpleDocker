"""menu/resources_menu.py — Resource limits (cgroups) — matches bash _resources_menu 1:1"""

import os
import json
import subprocess
from functions.constants import GRN, RED, CYN, BLD, DIM, NC, L, FZF_BASE
from functions.tui import confirm, pause, finput
from functions.utils import trim_s, strip_ansi, make_tmp
from functions.container import load_containers, cname as ct_cname
import functions.tui as _tui


def _fzf_raw(items, *extra_args):
    out_f = make_tmp(".sd_res_fzf_")
    try:
        proc = subprocess.Popen(
            ["fzf"] + list(FZF_BASE) + list(extra_args),
            stdin=subprocess.PIPE, stdout=open(out_f, "wb"),
        )
        proc.stdin.write("\n".join(items).encode())
        proc.stdin.close()
        rc = proc.wait()
        sel = open(out_f).read().strip() if rc == 0 else ""
        return rc, sel
    finally:
        try:
            os.unlink(out_f)
        except Exception:
            pass


def _res_cfg(containers_dir, cid):
    return os.path.join(containers_dir, cid, "resources.json")


def _res_get(containers_dir, cid, key):
    try:
        data = json.loads(open(_res_cfg(containers_dir, cid)).read())
        return str(data.get(key, ""))
    except Exception:
        return ""


def _res_set(containers_dir, cid, key, value):
    cfg = _res_cfg(containers_dir, cid)
    try:
        data = json.loads(open(cfg).read()) if os.path.isfile(cfg) else {}
    except Exception:
        data = {}
    data[key] = value
    with open(cfg, "w") as f:
        json.dump(data, f)


def _res_del(containers_dir, cid, key):
    cfg = _res_cfg(containers_dir, cid)
    try:
        data = json.loads(open(cfg).read()) if os.path.isfile(cfg) else {}
        data.pop(key, None)
        with open(cfg, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


def resources_menu(ctx):
    ids, names, _ = load_containers(ctx.containers_dir)
    if not ids:
        pause("No containers found.")
        return

    lines = [f"{BLD}  \u2500\u2500 Containers \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"]
    for cid, name in zip(ids, names):
        enabled = _res_get(ctx.containers_dir, cid, "enabled")
        rs = f"  {GRN}[cgroups on]{NC}" if enabled == "true" else ""
        lines.append(f" {DIM}\u25c8{NC}  {name}{rs}")

    lines += [
        f"{BLD}  \u2500\u2500 Navigation \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}",
        f"{DIM} {L['back']}{NC}",
    ]

    rc, sel = _fzf_raw(
        lines,
        f"--header={BLD}\u2500\u2500 Resource limits \u2500\u2500{NC}  {DIM}[{len(ids)} containers]{NC}",
    )
    if rc != 0 or not sel:
        return
    chosen = trim_s(sel)
    if not chosen or chosen == L["back"] or chosen.startswith("\u2500"):
        return

    sel_name = strip_ansi(chosen).replace("\u25c8", "").replace("[cgroups on]", "").strip().split()[0]
    cid = ""
    for ci, name in zip(ids, names):
        if name == sel_name:
            cid = ci
            break
    if not cid:
        return

    if not os.path.isfile(_res_cfg(ctx.containers_dir, cid)):
        with open(_res_cfg(ctx.containers_dir, cid), "w") as f:
            json.dump({"enabled": False}, f)

    _resources_per_ct(ctx.containers_dir, cid)


def _resources_per_ct(containers_dir, cid):
    name = ct_cname(containers_dir, cid)
    SEP_CFG  = f"{BLD}  \u2500\u2500 Configuration \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"
    SEP_INFO = f"{BLD}  \u2500\u2500 Info \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"
    SEP_NAV  = f"{BLD}  \u2500\u2500 Navigation \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"

    while True:
        enabled    = _res_get(containers_dir, cid, "enabled") or "false"
        cpu_quota  = _res_get(containers_dir, cid, "cpu_quota")  or "(unlimited)"
        mem_max    = _res_get(containers_dir, cid, "mem_max")    or "(unlimited)"
        mem_swap   = _res_get(containers_dir, cid, "mem_swap")   or "(unlimited)"
        cpu_weight = _res_get(containers_dir, cid, "cpu_weight") or "(default 100)"

        if enabled == "true":
            tog = f"{GRN}\u25cf Enabled{NC}"
        else:
            tog = f"{RED}\u25cb Disabled{NC}"

        lines = [
            SEP_CFG,
            f" {tog}  \u2014 toggle cgroups on/off (applies on next start)",
            f"  CPU quota    {CYN}{cpu_quota}{NC}  \u2014 e.g. 200% = 2 cores",
            f"  Memory max   {CYN}{mem_max}{NC}  \u2014 e.g. 8G, 512M",
            f"  Memory+swap  {CYN}{mem_swap}{NC}  \u2014 e.g. 10G",
            f"  CPU weight   {CYN}{cpu_weight}{NC}  \u2014 1-10000, default=100 (relative priority)",
            SEP_INFO,
            f"  {DIM}GPU/VRAM{NC}     not configurable via cgroups (planned separately)",
            f"  {DIM}Network{NC}      not configurable via cgroups (planned separately)",
            SEP_NAV,
            f"{DIM} {L['back']}{NC}",
        ]

        hdr = (f"{BLD}\u2500\u2500 Resources: {name} \u2500\u2500{NC}\n"
               f"{DIM}  Limits apply on container restart via systemd cgroups.{NC}")
        rc, sel = _fzf_raw(lines, f"--header={hdr}")
        if rc != 0 or not sel:
            return
        sc = strip_ansi(trim_s(sel)).lstrip()

        if sc.startswith(L["back"]) or sc.startswith("\u2500"):
            return
        elif "toggle" in sc:
            _res_set(containers_dir, cid, "enabled", "false" if enabled == "true" else "true")
        elif "CPU quota" in sc:
            if finput("CPU quota (e.g. 200% = 2 cores, blank = remove limit):"):
                v = _tui.FINPUT_RESULT.strip()
                if v:
                    _res_set(containers_dir, cid, "cpu_quota", v)
                else:
                    _res_del(containers_dir, cid, "cpu_quota")
        elif "Memory max" in sc and "swap" not in sc:
            if finput("Memory max (e.g. 8G, 512M, blank = remove limit):"):
                v = _tui.FINPUT_RESULT.strip()
                if v:
                    _res_set(containers_dir, cid, "mem_max", v)
                else:
                    _res_del(containers_dir, cid, "mem_max")
        elif "Memory+swap" in sc:
            if finput("Memory+swap max (e.g. 10G, blank = remove limit):"):
                v = _tui.FINPUT_RESULT.strip()
                if v:
                    _res_set(containers_dir, cid, "mem_swap", v)
                else:
                    _res_del(containers_dir, cid, "mem_swap")
        elif "CPU weight" in sc:
            if finput("CPU weight (1-10000, blank = default 100):"):
                v = _tui.FINPUT_RESULT.strip()
                if v:
                    _res_set(containers_dir, cid, "cpu_weight", v)
                else:
                    _res_del(containers_dir, cid, "cpu_weight")
