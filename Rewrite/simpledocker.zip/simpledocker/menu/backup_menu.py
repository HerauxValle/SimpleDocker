"""menu/backup_menu.py — Container backups (matches bash _container_backups_menu 1:1)"""

import os
import subprocess
from functions.constants import GRN, RED, BLD, DIM, NC, L, FZF_BASE, TMP_DIR
from functions.tui import menu, confirm, pause, finput
from functions.utils import trim_s, strip_ansi, tmux_up, tsess, make_tmp
from functions.container import (
    cname, cpath, snap_dir,
    snap_meta_get, snap_meta_set, delete_snap, rand_snap_id,
)
import functions.tui as _tui


def _fzf_raw(items, *extra_args):
    out_f = make_tmp(".sd_bkp_fzf_")
    try:
        proc = subprocess.Popen(
            ["fzf"] + list(FZF_BASE) + list(extra_args),
            stdin=subprocess.PIPE, stdout=open(out_f, "wb"),
        )
        proc.stdin.write("\n".join(items).encode())
        proc.stdin.close()
        rc = proc.wait()
        try:
            sel = open(out_f).read().strip()
        except Exception:
            sel = ""
        return rc, sel
    finally:
        try:
            os.unlink(out_f)
        except Exception:
            pass


def container_backups_menu(cid: str, containers_dir: str, installations_dir: str, backup_dir: str):
    ct_name = cname(containers_dir, cid)
    bd = snap_dir(backup_dir, cid, ct_name)
    os.makedirs(bd, exist_ok=True)

    SEP_AUTO = f"{BLD}  \u2500\u2500 Automatic backups \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"
    SEP_MAN  = f"{BLD}  \u2500\u2500 Manual backups \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"
    SEP_ACT  = f"{BLD}  \u2500\u2500 Actions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"
    SEP_NAV  = f"{BLD}  \u2500\u2500 Navigation \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500{NC}"

    while True:
        os.makedirs(bd, exist_ok=True)
        auto_ids, auto_ts = [], []
        man_ids, man_ts   = [], []

        # Scan .meta files to find auto vs manual backups
        if os.path.isdir(bd):
            for f in sorted(os.listdir(bd)):
                if not f.endswith(".meta"):
                    continue
                fid = f[:-5]
                if not os.path.isdir(os.path.join(bd, fid)):
                    continue
                ftype = snap_meta_get(bd, fid, "type") or ""
                fts   = snap_meta_get(bd, fid, "ts")   or ""
                if ftype == "auto":
                    auto_ids.append(fid); auto_ts.append(fts)
                else:
                    man_ids.append(fid);  man_ts.append(fts)

        lines, line_ids = [], []

        lines.append(SEP_AUTO); line_ids.append("")
        if auto_ids:
            for aid, ats in zip(auto_ids, auto_ts):
                disp = f"{DIM} \u25c8  {aid}{NC}"
                if ats:
                    disp += f"{DIM}  ({ats}){NC}"
                lines.append(disp); line_ids.append(aid)
        else:
            lines.append(f"{DIM}  (none yet){NC}"); line_ids.append("")

        lines.append(SEP_MAN); line_ids.append("")
        if man_ids:
            for mid, mts in zip(man_ids, man_ts):
                disp = f"{DIM} \u25c8  {mid}{NC}"
                if mts:
                    disp += f"{DIM}  ({mts}){NC}"
                lines.append(disp); line_ids.append(mid)
        else:
            lines.append(f"{DIM}  (none yet){NC}"); line_ids.append("")

        lines.append(SEP_ACT); line_ids.append("")
        lines.append(f"{GRN}+{NC}{DIM}  Create manual backup{NC}"); line_ids.append("__create__")
        lines.append(f"{RED}\u00d7{NC}{DIM}  Remove all backups{NC}");   line_ids.append("__remove_all__")
        lines.append(SEP_NAV); line_ids.append("")
        lines.append(f"{DIM} {L['back']}{NC}"); line_ids.append("__back__")

        rc, sel = _fzf_raw(lines, f"--header={BLD}\u2500\u2500 Backups: {ct_name} \u2500\u2500{NC}")
        if rc != 0 or not sel:
            return

        sel_clean = trim_s(sel)
        sel_id = ""
        for i, line in enumerate(lines):
            if trim_s(line) == sel_clean:
                sel_id = line_ids[i]
                break

        if not sel_id or sel_id == "__back__":
            return

        if sel_id == "__create__":
            if tmux_up(tsess(cid)):
                pause("Stop the container before creating a backup.")
                continue
            if confirm(f"Create manual backup of '{ct_name}'?"):
                _create_manual_backup(cid, containers_dir, installations_dir, bd)
            continue

        if sel_id == "__remove_all__":
            if tmux_up(tsess(cid)):
                pause("Stop the container before removing backups.")
                continue
            rc2 = menu(f"Remove backups: {ct_name}",
                       "All automatic", "All manual", "All (automatic + manual)")
            if rc2 != 0:
                continue
            rm_choice = _tui.REPLY
            rm_auto = "automatic" in rm_choice or "automatic + manual" in rm_choice
            rm_man  = "manual" in rm_choice and ("All manual" in rm_choice or "automatic + manual" in rm_choice)
            rm_count = 0
            if rm_auto:
                for aid in auto_ids:
                    _delete_backup(bd, aid); rm_count += 1
            if rm_man:
                for mid in man_ids:
                    _delete_backup(bd, mid); rm_count += 1
            pause(f"{rm_count} backup(s) removed.")
            continue

        if not os.path.isdir(os.path.join(bd, sel_id)):
            pause("Backup not found.")
            continue

        bts = snap_meta_get(bd, sel_id, "ts") or "?"
        rc3 = menu(f"Backup: {sel_id}  ({bts})", "Restore", "Create clone", "Delete")
        if rc3 != 0:
            continue
        action = _tui.REPLY

        if action == "Restore":
            if tmux_up(tsess(cid)):
                pause("Stop the container before restoring.")
                continue
            _do_restore_snap(cid, containers_dir, installations_dir, bd, sel_id)

        elif action == "Create clone":
            if tmux_up(tsess(cid)):
                pause("Stop the container before cloning.")
                continue
            if not finput("Name for the clone:"):
                continue
            clone_name = _tui.FINPUT_RESULT.strip()
            if clone_name:
                _clone_from_snap(cid, containers_dir, installations_dir,
                                 bd, sel_id, clone_name)

        elif action == "Delete":
            if confirm(f"Delete backup '{sel_id}'?"):
                _delete_backup(bd, sel_id)
                pause(f"Backup '{sel_id}' deleted.")


# ── Snapshot helpers ──────────────────────────────────────────────────────

def _create_manual_backup(cid, containers_dir, installations_dir, bd):
    import datetime
    ct_name = cname(containers_dir, cid)
    ip = cpath(containers_dir, installations_dir, cid)
    if not ip or not os.path.isdir(ip):
        pause(f"No installation found for '{ct_name}'.")
        return

    # Prompt for name
    default_id = rand_snap_id(bd)
    if finput(f"Backup name:\n  (leave blank for random: {default_id})"):
        raw = _tui.FINPUT_RESULT.strip()
        import re
        snap_id = re.sub(r'[^a-zA-Z0-9_\-]', '', raw) or default_id
    else:
        snap_id = default_id

    if os.path.isdir(os.path.join(bd, snap_id)):
        pause(f"A backup named '{snap_id}' already exists.")
        return

    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    r = subprocess.run(
        ["sudo", "-n", "btrfs", "subvolume", "snapshot", "-r", ip,
         os.path.join(bd, snap_id)],
        stderr=subprocess.DEVNULL,
    )
    if r.returncode != 0:
        import shutil
        try:
            shutil.copytree(ip, os.path.join(bd, snap_id))
        except Exception as e:
            pause(f"Snapshot failed: {e}")
            return
    snap_meta_set(bd, snap_id, type="manual", ts=ts)
    pause(f"Backup '{snap_id}' created.")


def _do_restore_snap(cid, containers_dir, installations_dir, bd, snap_id):
    ct_name = cname(containers_dir, cid)
    snap_path = os.path.join(bd, snap_id)
    ip = cpath(containers_dir, installations_dir, cid)
    if not confirm(
        f"Restore '{ct_name}' from '{snap_id}'?\n\n"
        "  Current installation will be overwritten.\n"
        "  Persistent storage profiles are untouched."
    ):
        return
    subprocess.run(["sudo", "-n", "btrfs", "property", "set", snap_path, "ro", "false"],
                   stderr=subprocess.DEVNULL)
    subprocess.run(["sudo", "-n", "btrfs", "subvolume", "delete", ip],
                   stderr=subprocess.DEVNULL)
    r = subprocess.run(
        ["sudo", "-n", "btrfs", "subvolume", "snapshot", snap_path, ip],
        stderr=subprocess.DEVNULL,
    )
    if r.returncode != 0:
        import shutil
        shutil.copytree(snap_path, ip, dirs_exist_ok=True)
    subprocess.run(["sudo", "-n", "btrfs", "property", "set", snap_path, "ro", "true"],
                   stderr=subprocess.DEVNULL)
    pause(f"Restored '{ct_name}' from '{snap_id}'.")


def _clone_from_snap(cid, containers_dir, installations_dir, bd, snap_id, clone_name):
    import secrets, shutil
    from functions.utils import read_json, write_json
    src_name  = cname(containers_dir, cid)
    snap_path = os.path.join(bd, snap_id)
    if not os.path.isdir(snap_path):
        pause("Snapshot not found.")
        return
    clone_cid  = secrets.token_hex(4)
    clone_dir  = os.path.join(containers_dir, clone_cid)
    clone_path = os.path.join(installations_dir, clone_cid)
    os.makedirs(clone_dir, exist_ok=True)
    for f_ in ["service.json", "state.json", "resources.json"]:
        src_f = os.path.join(containers_dir, cid, f_)
        if os.path.isfile(src_f):
            shutil.copy2(src_f, os.path.join(clone_dir, f_))
    st = read_json(os.path.join(clone_dir, "state.json")) or {}
    st["name"] = clone_name
    st["install_path"] = clone_cid
    write_json(os.path.join(clone_dir, "state.json"), st)
    r = subprocess.run(
        ["sudo", "-n", "btrfs", "subvolume", "snapshot", snap_path, clone_path],
        stderr=subprocess.DEVNULL,
    )
    if r.returncode == 0:
        subprocess.run(["sudo", "-n", "btrfs", "property", "set", clone_path, "ro", "false"],
                       stderr=subprocess.DEVNULL)
        pause(f"Cloned '{src_name}' ({snap_id}) \u2192 '{clone_name}'")
    else:
        try:
            shutil.copytree(snap_path, clone_path)
            pause(f"Cloned '{src_name}' ({snap_id}) \u2192 '{clone_name}' (plain copy)")
        except Exception as e:
            shutil.rmtree(clone_dir, ignore_errors=True)
            pause(f"Clone failed: {e}")


def _delete_backup(bd, snap_id):
    snap_path = os.path.join(bd, snap_id)
    delete_snap(snap_path)
    try:
        os.unlink(os.path.join(bd, snap_id + ".meta"))
    except Exception:
        pass
